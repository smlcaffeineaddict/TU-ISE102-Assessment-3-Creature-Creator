#include "Card.h"
#include "include/handy_functions.h"
#include "include/ise102.h"
#include <iostream>

// Print out the attributes of a card, ideally with user 
// friendly formatting.
void printCard(Card card) {
  // TODO: print out each attribute of the dog accessing
  // each one with dot notation just like in main. Name
  print("\tName: {0} \n", card.name); // example using fmt print
  // print("\t____: {0}kg \n", _______);  // uncomment and fill in the blanks
}

int main() {
  // Uses the generic Card object to store the details of two dogs.
  Card dog_0;
  dog_0.name = "Leroy";
  dog_0.weight_kg = 19.12;

  Card dog_1;
  dog_1.name = "Noszli";
  dog_1.weight_kg = 28.65;

  // TODO: Add a dog that you've known in real life or on tv

  printCard(dog_0);
  // TODO: print second doggo
}