#ifndef __CARD__
#define __CARD__
#include <string>

// A basic example of a collectible or record card with 
// some generic properties. "name" and "weight" could be
// applied to people, monsters, cars, famous gold nuggets, 
// magic swords, birds (where name could mean name of 
// species/type) etc.
class Card
{
public:
    std::string name;        
    float weight_kg = 0.0f;
    
};  // Note, a class needs a semi colon after the final }

#endif // __CARD__