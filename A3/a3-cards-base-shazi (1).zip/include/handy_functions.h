#ifndef __handy_functions__
#define __handy_functions__
// Get access to things in constants while coding on replit.
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <string>
#include "ise102.h"
#include "constants.h"
using namespace std;
using std::string;

// Add any handy, reusable, utility functions here

// Converts US/Imperial inches to metric (Système Internationale) cms.
int inchesToCms(int inches)
{
// TODO: Check if this works. Fix it if it doesn't (google inches to cms)
  int cms = inches / 3.54f;
  return cms;
}

#endif